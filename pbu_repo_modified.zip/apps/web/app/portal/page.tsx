export default async function PortalPage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Student Portal</h1>
      <p>Your private profile card and goals live here.</p>
    </main>
  );
}
