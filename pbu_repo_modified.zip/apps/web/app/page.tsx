export default function Page() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Plant Based University</h1>
      <p>Choose your team. Then upload a photo to see your PBU fit.</p>
      <a href="/portal">Go to Student Portal →</a>
    </main>
  );
}
